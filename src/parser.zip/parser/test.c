#include <stdio.h>
#include <stdlib.h>
#include "defined_values.h"
#include "configs.h"
#include <stddef.h>

int testparse(){
  int eror_tracker = 0;
  pair **array = malloc(4*sizeof(pair ));

  for(int i = 0 ; i<NUMBER_OF_CONFIG_INFORMATION;i++){
    array[i] = malloc(sizeof(pair));
  }

  if (SUCCESS == (eror_tracker = parse_file(USER_CONFIG_FILE ,array,LINE_MAX_LENGHT,MAXLEN,NUMBER_OF_CONFIG_INFORMATION)))
     for(int i = 0 ; i<NUMBER_OF_CONFIG_INFORMATION;i++){
    printf("key : %s \nvalue : %s \n",array[i]->key,array[i]->value);
  }
  for(int i = 0 ; i<NUMBER_OF_CONFIG_INFORMATION;i++){
   free_pair(array[i]);
   free(array[i]);
  }
  free(array);
}

void main(){
  testparse();
}
