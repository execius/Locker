#ifndef DEFINED_VALUES
#define DEFINED_VALUES

#define USER_CONFIG_FILE "configs.test" 
#define LINE_MAX_LENGHT (2*MAXLEN+3)// 2 MAXLEN for key and value , +3 for # and = and ;

enum constant_values{
 NUMBER_OF_CONFIG_INFORMATION = 4, 
 MAXLEN = 4096,      //maximum string lengh
 NUMBER_OF_INIT_VARS = 4 //number of thing that we will ask the user for in the initialization
};



#endif //DEFINED_VALUES
