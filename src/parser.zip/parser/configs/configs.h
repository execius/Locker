//the eror code is in src/headers/eror_handling/eror_handling.h
//all the globaly defined values are  src/headers/defined_values/defined_values.h

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "eror_handling.h"
#include "defined_values.h"
#include "pair_utils.h"

#ifndef CONF_PARSE
#define CONF_PARSE





int  linecheck(char *line, int maxlengh);
int parse_file(char *filename ,pair **array_of_pairs ,int line_max_len,int str_maxlengh,int max_numberoflines);
#endif //CONF_PARSE

